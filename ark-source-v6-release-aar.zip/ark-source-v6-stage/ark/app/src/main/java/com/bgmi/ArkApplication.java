package com.bgmi;

import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.util.Log;

import com.mundo.MundoCore;
import com.mundo.app.configuration.ClientConfiguration;
import com.bgmi.deviceid.VirtualAndroidIdHook;
import com.bgmi.deviceid.VirtualDeviceIdStore;

import org.lsposed.hiddenapibypass.HiddenApiBypass;

import java.io.File;

@SuppressWarnings({"unused","deprecation"})
public class ArkApplication extends Application {

    static {
        try { System.loadLibrary("shaitaan"); }
        catch (UnsatisfiedLinkError ignored) {}
    }

    public static native String getSdkKey();
    private static final String TAG = "ArkApp";

    @Override
    protected void attachBaseContext(Context base) {
        Log.w("MundoGms", "=== ArkApplication.attachBaseContext START ===");

        // 1. Hidden API bypass (Hcore requirement)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try { HiddenApiBypass.addHiddenApiExemptions("L"); }
            catch (Throwable t) { Log.w(TAG, "HiddenApiBypass: " + t.getMessage()); }
        }

        // 2. Decrypt + load the panel dex payload
        try { DexDecryptor.install(base); }
        catch (Throwable e) { Log.e(TAG, "Dex: " + e.getMessage()); }

        super.attachBaseContext(base);

        // 3. Device ID IPC hook — MUST be before doAttachBaseContext
        try { VirtualAndroidIdHook.registerEarlyHook(base); }
        catch (Throwable t) { Log.w(TAG, "DeviceId early hook: " + t); }

        // 4. Init Hcore virtual space
        try {
            Log.w("MundoGms", "About to call MundoCore.doAttachBaseContext");
            MundoCore.get().doAttachBaseContext(base, new ClientConfiguration() {
                @Override public String getHostPackageName() { return base.getPackageName(); }
                @Override public boolean isEnableDaemonService() { return false; }
                @Override public boolean requestInstallPackage(File file) { return false; }
            });
            Log.w("MundoGms", "MundoCore.doAttachBaseContext completed OK");
        } catch (Throwable e) {
            Log.w("MundoGms", "MundoCore.doAttachBaseContext CRASHED: " + e);
            e.printStackTrace();
        }

        // Diagnostic log
        try {
            File lib = new File(base.getFilesDir(), "loader/libbgmi.so");
            Log.d(TAG, "PROCESS START — lib exists=" + lib.exists()
                  + " size=" + (lib.exists() ? lib.length() : 0)
                  + " process=" + getProcessNameCompat(base));
        } catch (Exception ignored) {}
    }

    @Override
    public void onCreate() {
        super.onCreate();

        // Register in-process lifecycle callback BEFORE doCreate so beforeApplicationOnCreate fires
        try {
            VirtualDeviceIdStore store = new VirtualDeviceIdStore(getApplicationContext());
            String id = store.desired().isEmpty() ? store.change() : store.desired();
            VirtualAndroidIdHook.setupInterceptor(getApplicationContext(), id);
        } catch (Throwable t) { Log.w(TAG, "setupInterceptor: " + t); }

        // Hcore doCreate — triggers beforeApplicationOnCreate for BGMI virtual process
        try {
            Log.w("MundoGms", "About to call MundoCore.doCreate");
            MundoCore.get().doCreate();
            Log.w("MundoGms", "MundoCore.doCreate completed OK");
        } catch (Throwable e) {
            Log.w("MundoGms", "MundoCore.doCreate CRASHED: " + e);
        }
        // Activate SDK (MetaActivationManager class is same in Hcore)
        try { com.mundo.core.system.api.MetaActivationManager.activateSdk(getSdkKey()); }
        catch (Exception e) { Log.e(TAG, "SDK activation: " + e.getMessage()); }
        try { disableFirebase(); } catch (Exception ignored) {}

        // Host process only — virtual processes stop here
        boolean isHost;
        try { isHost = getPackageName().equals(getProcessNameCompat(this)); }
        catch (Exception e) { isHost = true; }
        if (!isHost) return;

        initDeviceId();
    }

    private String getProcessNameCompat(Context base) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 28)
                return Application.getProcessName();
            int pid = android.os.Process.myPid();
            android.app.ActivityManager am =
                (android.app.ActivityManager) base.getSystemService(ACTIVITY_SERVICE);
            if (am != null)
                for (android.app.ActivityManager.RunningAppProcessInfo p : am.getRunningAppProcesses())
                    if (p.pid == pid) return p.processName;
        } catch (Exception ignored) {}
        return "?";
    }

    private void initDeviceId() {
        new Thread(() -> {
            try {
                android.content.Context ctx = getApplicationContext();
                VirtualDeviceIdStore store = new VirtualDeviceIdStore(ctx);
                String id = store.desired().isEmpty() ? store.change() : store.desired();
                VirtualAndroidIdHook.registerEarlyHook(ctx);    // re-register with current ID
                Log.i(TAG, "initDeviceId: id=" + id);
            } catch (Throwable t) {
                Log.w(TAG, "initDeviceId FAILED: " + t);
            }
        }, "ArkDeviceIdInit").start();
    }

    private void disableFirebase() throws Exception {
        Class<?> fb = Class.forName("com.google.firebase.messaging.FirebaseMessaging");
        java.lang.reflect.Method m = fb.getDeclaredMethod("setAutoInitEnabled", boolean.class);
        m.invoke(fb.getMethod("getInstance").invoke(null), false);
    }
}
